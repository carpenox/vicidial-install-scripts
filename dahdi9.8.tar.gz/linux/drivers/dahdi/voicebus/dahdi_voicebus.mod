/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/voicebus/voicebus.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/voicebus/GpakCust.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/voicebus/GpakApi.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/voicebus/voicebus_net.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/voicebus/vpmoct.o
