/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wct4xxp/base.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wct4xxp/vpm450m.o
