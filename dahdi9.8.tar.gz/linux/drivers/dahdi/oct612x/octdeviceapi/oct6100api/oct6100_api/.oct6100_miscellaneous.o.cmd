cmd_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o := gcc -Wp,-MMD,/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/.oct6100_miscellaneous.o.d -nostdinc -I./arch/x86/include -I./arch/x86/include/generated  -I./include -I./arch/x86/include/uapi -I./arch/x86/include/generated/uapi -I./include/uapi -I./include/generated/uapi -include ./include/linux/compiler-version.h -include ./include/linux/kconfig.h -include ./include/linux/compiler_types.h -D__KERNEL__ -fmacro-prefix-map=./= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu11 -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=none -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -mtune=generic -mno-red-zone -mcmodel=kernel -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-address-of-packed-member -O2 -fno-allow-store-data-races -Wframe-larger-than=2048 -fstack-protector-strong -Wno-main -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-stack-clash-protection -g -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fno-inline-functions-called-once -falign-functions=16 -Wvla -Wno-pointer-sign -Wcast-function-type -Wno-stringop-truncation -Wno-stringop-overflow -Wno-restrict -Wno-maybe-uninitialized -Wno-array-bounds -Wno-alloc-size-larger-than "-Wimplicit-fallthrough=5" -fno-strict-overflow -fno-stack-check -fconserve-stack -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wno-packed-not-aligned -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/.. -Wno-undef -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api  -DMODULE -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/include -I/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi -Wno-format-truncation -DHAVE_WAIT_FOR_COMPLETION_TIMEOUT=1 -DKBUILD_BASENAME='"oct6100_miscellaneous"' -DKBUILD_MODNAME='"oct612x"' -D__KBUILD_MODNAME=kmod_oct612x -c -o /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.c   ; ./tools/objtool/objtool --hacks=jump_label --hacks=noinstr --hacks=skylake --orc --retpoline --rethunk --sls --static-call --uaccess --prefix=16   --module /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o

source_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o := /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.c

deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o := \
  include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_IS_GCC) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  include/linux/compiler_attributes.h \
  include/linux/compiler-gcc.h \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/KCOV) \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/octdef.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/octosdependant.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/octtype.h \
  include/linux/stddef.h \
  include/uapi/linux/stddef.h \
  include/linux/compiler_types.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/digium_unused.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_defines.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_errors.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/apilib/octapi_largmath.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_apiud.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_tlv_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_chip_open_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_chip_stats_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_interrupts_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_remote_debug_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_debug_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_api_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_channel_inst.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_interrupts_pub.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_chip_open_pub.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/include/oct6100api/oct6100_channel_pub.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_chip_open_priv.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_channel_priv.h \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_miscellaneous_priv.h \

/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o: $(deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o)

$(deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o):

/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/oct612x/octdeviceapi/oct6100api/oct6100_api/oct6100_miscellaneous.o: $(wildcard ./tools/objtool/objtool)
