/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/card_fxs.o
