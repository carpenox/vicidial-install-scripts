cmd_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o := gcc -Wp,-MMD,/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/.print_fxo_modes.o.d -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu11   -I ./scripts/include    -include /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/../fxo_modes.h -c -o /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.c

source_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o := /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.c

deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o := \
  /usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/../fxo_modes.h \

/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o: $(deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o)

$(deps_/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/print_fxo_modes.o):
