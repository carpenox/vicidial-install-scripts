/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xbus-core.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xbus-sysfs.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xbus-pcm.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xframe_queue.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xpp_dahdi.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/xproto.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/card_global.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/xpp/dahdi_debug.o
