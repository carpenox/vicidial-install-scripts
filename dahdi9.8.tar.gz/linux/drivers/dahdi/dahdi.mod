/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/dahdi-base.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/dahdi-sysfs.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/dahdi-sysfs-chan.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/dahdi-version.o
