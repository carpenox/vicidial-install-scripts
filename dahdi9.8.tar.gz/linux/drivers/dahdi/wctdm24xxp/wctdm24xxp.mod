/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wctdm24xxp/base.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wctdm24xxp/xhfc.o
