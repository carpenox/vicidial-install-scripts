#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(dahdi_transcoder_register, "", "");
KSYMTAB_FUNC(dahdi_transcoder_unregister, "", "");
KSYMTAB_FUNC(dahdi_transcoder_alert, "", "");
KSYMTAB_FUNC(dahdi_transcoder_alloc, "", "");
KSYMTAB_FUNC(dahdi_transcoder_free, "", "");

SYMBOL_CRC(dahdi_transcoder_register, 0x80412227, "");
SYMBOL_CRC(dahdi_transcoder_unregister, 0x03658db5, "");
SYMBOL_CRC(dahdi_transcoder_alert, 0x791c0305, "");
SYMBOL_CRC(dahdi_transcoder_alloc, 0x40b66cca, "");
SYMBOL_CRC(dahdi_transcoder_free, 0x2be03eb8, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x345d7f7a, "dahdi_transcode_fops" },
	{ 0x37a0cba, "kfree" },
	{ 0xe2964344, "__wake_up" },
	{ 0x680a04a6, "module_put" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xa916b694, "strnlen" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x5d662e5, "dahdi_unregister_chardev" },
	{ 0x122c3a7e, "_printk" },
	{ 0x597475a3, "dahdi_register_chardev" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xdf68b21a, "try_module_get" },
	{ 0x3de92247, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xfb578fc5, "memset" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "026B921EEF42BE3F8722E6A");
MODULE_INFO(rhelversion, "9.8");
