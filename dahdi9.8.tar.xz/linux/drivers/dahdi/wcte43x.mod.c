#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x84f16728, "pci_save_state" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xa78af5f3, "ioread32" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x3cbd072, "pci_find_ext_capability" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0xf249220c, "dma_pool_create" },
	{ 0x11956249, "pci_enable_device" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0x6a8a7260, "pci_iomap" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa6257a2f, "complete" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x9e22a8e, "dahdi_alarm_notify" },
	{ 0x8ad215cc, "request_firmware" },
	{ 0x8a84ad48, "__pci_register_driver" },
	{ 0xa71d2e2c, "ioread16be" },
	{ 0x1cfc6de6, "pci_disable_msi" },
	{ 0x854f6e90, "pci_request_regions" },
	{ 0x37a0cba, "kfree" },
	{ 0xfcec0987, "enable_irq" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3c5d2d76, "__dynamic_dev_dbg" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xa498779d, "Oct6100ChannelModify" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0xf342750a, "pci_unregister_driver" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x678b96ec, "dma_pool_alloc" },
	{ 0x87e48eb1, "pci_read_config_dword" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x848d372e, "iowrite8" },
	{ 0x1d24c881, "___ratelimit" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x3ae3bf84, "queue_delayed_work_on" },
	{ 0xe419bc99, "iowrite32be" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x749cbadd, "_dev_info" },
	{ 0x93a4f6e7, "device_create_file" },
	{ 0x7dfa7432, "pci_find_capability" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0x442b102b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xefe25d60, "pci_enable_msi" },
	{ 0x2f60ef0a, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x2f7754a8, "dma_pool_free" },
	{ 0xb8acf091, "dahdi_create_device" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xfbc199da, "dma_alloc_attrs" },
	{ 0x757d3165, "pci_read_config_word" },
	{ 0x2d4d420f, "Oct6100ChipOpenDef" },
	{ 0x5a921311, "strncmp" },
	{ 0x8bcefb0d, "Oct6100GetInstanceSizeDef" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x642e7b9, "dahdi_init_span" },
	{ 0x9d281dd8, "dahdi_unregister_device" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd9becdfb, "pci_iounmap" },
	{ 0xa9963ebd, "pci_restore_state" },
	{ 0xb19b445, "ioread8" },
	{ 0xa175a655, "_dev_warn" },
	{ 0x8887613e, "Oct6100ChannelModifyDef" },
	{ 0x9bb4e317, "ioread32be" },
	{ 0x1938d602, "pci_set_master" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x7f3521aa, "Oct6100GetInstanceSize" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x41e338a2, "_dev_notice" },
	{ 0xb5aa7165, "dma_pool_destroy" },
	{ 0x1a4c24cc, "dma_free_attrs" },
	{ 0x999e8297, "vfree" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xf39d6569, "cancel_delayed_work_sync" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x679d4479, "__dahdi_ec_chunk" },
	{ 0x23f56e03, "pci_release_regions" },
	{ 0x26f8f0b8, "iowrite16be" },
	{ 0x6eefa3a6, "Oct6100ChipCloseDef" },
	{ 0xe59837f0, "Oct6100ChipClose" },
	{ 0x20728ec0, "Oct6100ChannelOpenDef" },
	{ 0xb0e6a56, "delayed_work_timer_fn" },
	{ 0x2a53b7e8, "pci_disable_device" },
	{ 0xd391db23, "dma_set_mask" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x3de92247, "param_ops_int" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x98826cf, "dahdi_free_device" },
	{ 0xa7c16b4, "pci_write_config_word" },
	{ 0x21ef374c, "try_wait_for_completion" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xef4b16bf, "Oct6100ChipOpen" },
	{ 0xeb66e2b8, "dahdi_rbsbits" },
	{ 0xf9a482f9, "msleep" },
	{ 0x4657edbb, "pci_write_config_dword" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x92d911b7, "_dahdi_transmit" },
	{ 0xd5f6af81, "device_remove_file" },
	{ 0x3ce4ca6f, "disable_irq" },
	{ 0xf8a56864, "Oct6100ChannelOpen" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi,oct612x");

MODULE_ALIAS("pci:v0000D161d0000800Esv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008013sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "F5026CA7AA7D0A3E67E4DB9");
MODULE_INFO(rhelversion, "9.8");
