#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xf342750a, "pci_unregister_driver" },
	{ 0x679d4479, "__dahdi_ec_chunk" },
	{ 0x442b102b, "_dahdi_receive" },
	{ 0x7aae1ec9, "dahdi_hooksig" },
	{ 0x92d911b7, "_dahdi_transmit" },
	{ 0x9e22a8e, "dahdi_alarm_notify" },
	{ 0xa5479a2, "__tracepoint_sched_set_state_tp" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x53bbefe1, "__trace_set_current_state" },
	{ 0x11956249, "pci_enable_device" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x85bd1608, "__request_region" },
	{ 0xfbc199da, "dma_alloc_attrs" },
	{ 0xb8acf091, "dahdi_create_device" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0x1938d602, "pci_set_master" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x3de92247, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x122c3a7e, "_printk" },
	{ 0x8a84ad48, "__pci_register_driver" },
	{ 0x9d281dd8, "dahdi_unregister_device" },
	{ 0x37a0cba, "kfree" },
	{ 0x98826cf, "dahdi_free_device" },
	{ 0xdbdf6c92, "ioport_resource" },
	{ 0x1035c7c2, "__release_region" },
	{ 0x1a4c24cc, "dma_free_attrs" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi");

MODULE_ALIAS("pci:v0000E159d00000001sv00008084sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00008085sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00008086sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00008087sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001057d00005608sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "C608820B571FD5F058EC162");
MODULE_INFO(rhelversion, "9.8");
