#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0x60a0394e, "skb_copy_bits" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x11956249, "pci_enable_device" },
	{ 0x46b3f072, "skb_put" },
	{ 0x6a8a7260, "pci_iomap" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa6257a2f, "complete" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x71e00ebe, "unregister_netdev" },
	{ 0x80dd25d9, "skb_dequeue" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xde758b23, "dma_unmap_page_attrs" },
	{ 0x8ad215cc, "request_firmware" },
	{ 0x8a84ad48, "__pci_register_driver" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x2be03eb8, "dahdi_transcoder_free" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0xc96c4376, "pci_clear_mwi" },
	{ 0x2a1cce53, "netif_napi_add_weight_locked" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xe2964344, "__wake_up" },
	{ 0xcf576d85, "kmem_cache_create" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x3ad7cd2b, "ether_setup" },
	{ 0xf342750a, "pci_unregister_driver" },
	{ 0x1035c7c2, "__release_region" },
	{ 0x40b66cca, "dahdi_transcoder_alloc" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xda8ab775, "dev_driver_string" },
	{ 0xf33ad055, "eth_type_trans" },
	{ 0xb803b79e, "dma_map_page_attrs" },
	{ 0xefb2b368, "napi_complete_done" },
	{ 0x2cd1900e, "alloc_netdev_mqs" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xe8911b20, "__napi_schedule" },
	{ 0x552be5f8, "__alloc_skb" },
	{ 0xbe1637a1, "kmem_cache_alloc" },
	{ 0x749cbadd, "_dev_info" },
	{ 0x6572cf93, "skb_queue_tail" },
	{ 0x791c0305, "dahdi_transcoder_alert" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x4ed815c7, "pci_set_mwi" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x2f60ef0a, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xa2646207, "sk_skb_reason_drop" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xb4b68521, "kmem_cache_free" },
	{ 0xfbc199da, "dma_alloc_attrs" },
	{ 0xd5da4271, "napi_enable" },
	{ 0x5f67cd9b, "netif_receive_skb" },
	{ 0xd946fbe6, "register_netdev" },
	{ 0x5d677b48, "free_netdev" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xfef216eb, "_raw_spin_trylock" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x80412227, "dahdi_transcoder_register" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd9becdfb, "pci_iounmap" },
	{ 0xfb578fc5, "memset" },
	{ 0xa175a655, "_dev_warn" },
	{ 0x1938d602, "pci_set_master" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x6d16c104, "mutex_lock_killable" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x1a4c24cc, "dma_free_attrs" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x56470118, "__warn_printk" },
	{ 0xd391db23, "dma_set_mask" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0xf920860b, "napi_schedule_prep" },
	{ 0x4e7e73a4, "pci_read_config_byte" },
	{ 0x754d539c, "strlen" },
	{ 0x67e0ce5, "napi_disable" },
	{ 0x77358855, "iomem_resource" },
	{ 0x7f5bd2af, "dev_kfree_skb_any_reason" },
	{ 0x3658db5, "dahdi_transcoder_unregister" },
	{ 0x3de92247, "param_ops_int" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xf9a482f9, "msleep" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x85bd1608, "__request_region" },
	{ 0x20741215, "kmem_cache_destroy" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi_transcode");

MODULE_ALIAS("pci:v0000D161d00003400sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008004sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "C35657F3D6F671F219DC3E1");
MODULE_INFO(rhelversion, "9.8");
