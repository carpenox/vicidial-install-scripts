#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xa72a0a41, "dahdi_dynamic_receive" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x122c3a7e, "_printk" },
	{ 0x37a0cba, "kfree" },
	{ 0x68371abe, "dahdi_dynamic_unregister_driver" },
	{ 0x754d539c, "strlen" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xebb429d3, "dahdi_dynamic_register_driver" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "07EE4381A85011B82FD2D8A");
MODULE_INFO(rhelversion, "9.8");
