/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/vpmadt032_loader/dahdi_vpmadt032_loader.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/vpmadt032_loader/vpmadt032_x86_64.o
