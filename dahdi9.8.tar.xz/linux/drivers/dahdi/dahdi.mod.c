#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_DATA(dahdi_transcode_fops, "", "");
KSYMTAB_FUNC(dahdi_init_tone_state, "", "");
KSYMTAB_FUNC(dahdi_mf_tone, "", "");
KSYMTAB_DATA(__dahdi_mulaw, "", "");
KSYMTAB_DATA(__dahdi_alaw, "", "");
KSYMTAB_DATA(__dahdi_lin2mu, "", "");
KSYMTAB_DATA(__dahdi_lin2a, "", "");
KSYMTAB_FUNC(dahdi_rbsbits, "", "");
KSYMTAB_FUNC(dahdi_qevent_nolock, "", "");
KSYMTAB_FUNC(dahdi_qevent_lock, "", "");
KSYMTAB_FUNC(dahdi_hooksig, "", "");
KSYMTAB_FUNC(dahdi_alarm_notify, "", "");
KSYMTAB_FUNC(dahdi_hdlc_abort, "", "");
KSYMTAB_FUNC(dahdi_hdlc_finish, "", "");
KSYMTAB_FUNC(dahdi_hdlc_getbuf, "", "");
KSYMTAB_FUNC(dahdi_hdlc_putbuf, "", "");
KSYMTAB_FUNC(dahdi_alarm_channel, "", "");
KSYMTAB_FUNC(dahdi_register_echocan_factory, "", "");
KSYMTAB_FUNC(dahdi_unregister_echocan_factory, "", "");
KSYMTAB_FUNC(dahdi_set_hpec_ioctl, "", "");
KSYMTAB_FUNC(dahdi_str2spantype, "", "");
KSYMTAB_FUNC(dahdi_spantype2str, "", "");
KSYMTAB_FUNC(dahdi_lineconfig_bit_name, "", "");
KSYMTAB_FUNC(lineconfig_str, "", "");
KSYMTAB_FUNC(dahdi_lboname, "", "");
KSYMTAB_FUNC(dahdi_set_dynamic_ops, "", "");
KSYMTAB_FUNC(dahdi_create_device, "", "");
KSYMTAB_FUNC(dahdi_free_device, "", "");
KSYMTAB_FUNC(dahdi_init_span, "", "");
KSYMTAB_FUNC(dahdi_get_auto_assign_spans, "", "");
KSYMTAB_FUNC(dahdi_register_device, "", "");
KSYMTAB_FUNC(dahdi_unregister_device, "", "");
KSYMTAB_FUNC(__dahdi_ec_chunk, "", "");
KSYMTAB_FUNC(_dahdi_ec_span, "", "");
KSYMTAB_FUNC(_dahdi_transmit, "", "");
KSYMTAB_FUNC(_dahdi_receive, "", "");
KSYMTAB_FUNC(dahdi_register_chardev, "", "");
KSYMTAB_FUNC(dahdi_unregister_chardev, "", "");

SYMBOL_CRC(dahdi_transcode_fops, 0x345d7f7a, "");
SYMBOL_CRC(dahdi_init_tone_state, 0xf42f429a, "");
SYMBOL_CRC(dahdi_mf_tone, 0xb323b551, "");
SYMBOL_CRC(__dahdi_mulaw, 0x006a2198, "");
SYMBOL_CRC(__dahdi_alaw, 0xc4071a06, "");
SYMBOL_CRC(__dahdi_lin2mu, 0x0cca3f0e, "");
SYMBOL_CRC(__dahdi_lin2a, 0xb48548fa, "");
SYMBOL_CRC(dahdi_rbsbits, 0xeb66e2b8, "");
SYMBOL_CRC(dahdi_qevent_nolock, 0x4acbd584, "");
SYMBOL_CRC(dahdi_qevent_lock, 0x4a0de96c, "");
SYMBOL_CRC(dahdi_hooksig, 0x7aae1ec9, "");
SYMBOL_CRC(dahdi_alarm_notify, 0x09e22a8e, "");
SYMBOL_CRC(dahdi_hdlc_abort, 0x732bc7e6, "");
SYMBOL_CRC(dahdi_hdlc_finish, 0x5ef8ce32, "");
SYMBOL_CRC(dahdi_hdlc_getbuf, 0x69cb88ea, "");
SYMBOL_CRC(dahdi_hdlc_putbuf, 0x33080f72, "");
SYMBOL_CRC(dahdi_alarm_channel, 0x77317a9b, "");
SYMBOL_CRC(dahdi_register_echocan_factory, 0x35b1fbbb, "");
SYMBOL_CRC(dahdi_unregister_echocan_factory, 0x2e66b251, "");
SYMBOL_CRC(dahdi_set_hpec_ioctl, 0xe5a73e62, "");
SYMBOL_CRC(dahdi_str2spantype, 0x2a2d0f08, "");
SYMBOL_CRC(dahdi_spantype2str, 0x4c29be43, "");
SYMBOL_CRC(dahdi_lineconfig_bit_name, 0xc597f0d1, "");
SYMBOL_CRC(lineconfig_str, 0xa95ae136, "");
SYMBOL_CRC(dahdi_lboname, 0xb909ae06, "");
SYMBOL_CRC(dahdi_set_dynamic_ops, 0xdeb6e8cd, "");
SYMBOL_CRC(dahdi_create_device, 0xb8acf091, "");
SYMBOL_CRC(dahdi_free_device, 0x098826cf, "");
SYMBOL_CRC(dahdi_init_span, 0x0642e7b9, "");
SYMBOL_CRC(dahdi_get_auto_assign_spans, 0x65d8edc0, "");
SYMBOL_CRC(dahdi_register_device, 0xf8c888d4, "");
SYMBOL_CRC(dahdi_unregister_device, 0x9d281dd8, "");
SYMBOL_CRC(__dahdi_ec_chunk, 0x679d4479, "");
SYMBOL_CRC(_dahdi_ec_span, 0xa143cfe1, "");
SYMBOL_CRC(_dahdi_transmit, 0x92d911b7, "");
SYMBOL_CRC(_dahdi_receive, 0x442b102b, "");
SYMBOL_CRC(dahdi_register_chardev, 0x597475a3, "");
SYMBOL_CRC(dahdi_unregister_chardev, 0x05d662e5, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x9c6febfc, "add_uevent_var" },
	{ 0xe914e41e, "strcpy" },
	{ 0xdf68b21a, "try_module_get" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x3dfcc644, "dev_set_name" },
	{ 0xb0e602eb, "memmove" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x1e6674a7, "device_unregister" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xc9d25db, "class_destroy" },
	{ 0x436acbc0, "device_initialize" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0xd5fd90f1, "prepare_to_wait" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0x34928c1, "seq_lseek" },
	{ 0x7551248c, "proc_create_data" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xe2964344, "__wake_up" },
	{ 0xe9d75131, "get_device" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xf3cec78b, "put_device" },
	{ 0x7682ba4e, "__copy_overflow" },
	{ 0xa916b694, "strnlen" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x749cbadd, "_dev_info" },
	{ 0x680a04a6, "module_put" },
	{ 0xc20414fb, "sysfs_create_link" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0xc1115412, "cdev_add" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x86412482, "bus_unregister" },
	{ 0x2f60ef0a, "_dev_err" },
	{ 0xe2a0e6b6, "device_add" },
	{ 0xea909b12, "sysfs_remove_link" },
	{ 0x3cf85989, "mod_timer" },
	{ 0xc0dba8e8, "device_create" },
	{ 0xd95496df, "class_create" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x4a19ad77, "driver_unregister" },
	{ 0x449ad0a7, "memcmp" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x2e2b40d2, "strncat" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x11089ac7, "_ctype" },
	{ 0x69819809, "device_register" },
	{ 0x24c8cc93, "device_del" },
	{ 0x32f55b2c, "proc_mkdir" },
	{ 0x1e1e140e, "ns_to_timespec64" },
	{ 0xfb578fc5, "memset" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x6ac32bfc, "proc_remove" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xcdafd0b5, "seq_read" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x41e338a2, "_dev_notice" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x7f03b6a9, "crc_ccitt_table" },
	{ 0x66cca4f9, "__x86_indirect_thunk_rcx" },
	{ 0x43c501a2, "__register_chrdev" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x4b4577bb, "device_destroy" },
	{ 0x9830f204, "remove_proc_entry" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x692cf7c3, "seq_printf" },
	{ 0xd7b1abdd, "kobject_uevent" },
	{ 0xa01936b1, "single_release" },
	{ 0xad73041f, "autoremove_wake_function" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x754d539c, "strlen" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x851d5838, "_dev_printk" },
	{ 0x4d56306b, "single_open" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xd35ce85b, "driver_register" },
	{ 0xf9a482f9, "msleep" },
	{ 0x5aaf13e, "cdev_init" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0xa7aab139, "cdev_del" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x1c432eb5, "bus_register" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "C9C2FEC653FD28BD0E052FD");
MODULE_INFO(rhelversion, "9.8");
