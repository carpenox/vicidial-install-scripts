#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x7d7d6fbb, "xframe_next_packet" },
	{ 0xa68e3b05, "xpd_driver_unregister" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x566f684f, "xpp_register_request" },
	{ 0x33080f72, "dahdi_hdlc_putbuf" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x69cb88ea, "dahdi_hdlc_getbuf" },
	{ 0x69acdf38, "memcpy" },
	{ 0x2e79ac2a, "xpd_alloc" },
	{ 0x34928c1, "seq_lseek" },
	{ 0xb2cc48ff, "elect_syncer" },
	{ 0x7551248c, "proc_create_data" },
	{ 0x20c1a87c, "dahdi_sync_tick" },
	{ 0x40d5fa67, "dump_xframe" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1ee9ef91, "xpp_close" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x42ab5778, "xpd_free" },
	{ 0xe84a4e7e, "update_wanted_pcm_mask" },
	{ 0x2ef28734, "pcmtx" },
	{ 0xe3dfaaf9, "xproto_register" },
	{ 0xe3f0a45a, "xproto_card_entry" },
	{ 0x5af82912, "mark_offhook" },
	{ 0x7979af1c, "xpp_echocan_create" },
	{ 0x732bc7e6, "dahdi_hdlc_abort" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x1663fcfc, "xpp_open" },
	{ 0xcdafd0b5, "seq_read" },
	{ 0xec5e384c, "notify_bad_xpd" },
	{ 0x823ae8b8, "param_ops_bool" },
	{ 0xbaad7b8d, "xpp_ioctl" },
	{ 0x9830f204, "remove_proc_entry" },
	{ 0x1455bd3, "put_xframe" },
	{ 0x5ef8ce32, "dahdi_hdlc_finish" },
	{ 0x56470118, "__warn_printk" },
	{ 0x692cf7c3, "seq_printf" },
	{ 0x9135474d, "xpp_echocan_name" },
	{ 0x4d9adb4a, "get_xframe" },
	{ 0xc37c49f2, "xpp_hooksig" },
	{ 0xb67272d2, "xpd_byaddr" },
	{ 0xcbd6d4f5, "report_bad_ioctl" },
	{ 0xa01936b1, "single_release" },
	{ 0x2f8b1791, "xpp_maint" },
	{ 0xc3b63d8, "pcmtx_chan" },
	{ 0x8f7a7c41, "xpp_span_assigned" },
	{ 0x7f88ed0c, "send_cmd_frame" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x4d56306b, "single_open" },
	{ 0x4b32adf, "xproto_unregister" },
	{ 0x9e812e0d, "xpd_driver_register" },
	{ 0x66902ede, "update_xpd_status" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "D7A13B210C07ACE1307DBC4");
MODULE_INFO(rhelversion, "9.8");
