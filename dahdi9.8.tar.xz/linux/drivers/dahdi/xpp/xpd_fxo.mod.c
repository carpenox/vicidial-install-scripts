#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xa68e3b05, "xpd_driver_unregister" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x566f684f, "xpp_register_request" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x543020e5, "hookstate_changed" },
	{ 0x220378b3, "generic_echocancel_setmask" },
	{ 0x2e79ac2a, "xpd_alloc" },
	{ 0x34928c1, "seq_lseek" },
	{ 0x6ff45dc5, "generic_timing_priority" },
	{ 0x7551248c, "proc_create_data" },
	{ 0x4cb74149, "generic_echocancel_timeslot" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x3759bc54, "generic_card_pcm_tospan" },
	{ 0x442a969b, "generic_card_pcm_fromspan" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x42ab5778, "xpd_free" },
	{ 0x93a4f6e7, "device_create_file" },
	{ 0x4a0de96c, "dahdi_qevent_lock" },
	{ 0xe3dfaaf9, "xproto_register" },
	{ 0xe3f0a45a, "xproto_card_entry" },
	{ 0x5af82912, "mark_offhook" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd496300b, "oht_pcm" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xcdafd0b5, "seq_read" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xec5e384c, "notify_bad_xpd" },
	{ 0x823ae8b8, "param_ops_bool" },
	{ 0x9830f204, "remove_proc_entry" },
	{ 0x692cf7c3, "seq_printf" },
	{ 0xcbd6d4f5, "report_bad_ioctl" },
	{ 0xa01936b1, "single_release" },
	{ 0x77317a9b, "dahdi_alarm_channel" },
	{ 0xefdbb440, "generic_card_pcm_recompute" },
	{ 0x92e38267, "notify_rxsig" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x4d56306b, "single_open" },
	{ 0x4b32adf, "xproto_unregister" },
	{ 0x9e812e0d, "xpd_driver_register" },
	{ 0xf9a482f9, "msleep" },
	{ 0xd5f6af81, "device_remove_file" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "E0B6335C50B645EB2AC8CBC");
MODULE_INFO(rhelversion, "9.8");
