#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x7d7d6fbb, "xframe_next_packet" },
	{ 0xa68e3b05, "xpd_driver_unregister" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x566f684f, "xpp_register_request" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x3ba889a4, "xpd_set_spanname" },
	{ 0x9e22a8e, "dahdi_alarm_notify" },
	{ 0x64a6fdeb, "alarm2str" },
	{ 0x2e79ac2a, "xpd_alloc" },
	{ 0xb2cc48ff, "elect_syncer" },
	{ 0x20c1a87c, "dahdi_sync_tick" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x96b29254, "strncasecmp" },
	{ 0x1ee9ef91, "xpp_close" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xe84a4e7e, "update_wanted_pcm_mask" },
	{ 0x93a4f6e7, "device_create_file" },
	{ 0x2ef28734, "pcmtx" },
	{ 0xe3dfaaf9, "xproto_register" },
	{ 0xe3f0a45a, "xproto_card_entry" },
	{ 0x5af82912, "mark_offhook" },
	{ 0x7979af1c, "xpp_echocan_create" },
	{ 0x642e7b9, "dahdi_init_span" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4130bfe5, "phonedev_alloc_channels" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x1663fcfc, "xpp_open" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x1ac5d3cb, "strcspn" },
	{ 0xec5e384c, "notify_bad_xpd" },
	{ 0xbaad7b8d, "xpp_ioctl" },
	{ 0x9135474d, "xpp_echocan_name" },
	{ 0x4d9adb4a, "get_xframe" },
	{ 0xb67272d2, "xpd_byaddr" },
	{ 0xcbd6d4f5, "report_bad_ioctl" },
	{ 0x97438c62, "dump_packet" },
	{ 0x2f8b1791, "xpp_maint" },
	{ 0xc3b63d8, "pcmtx_chan" },
	{ 0x8f7a7c41, "xpp_span_assigned" },
	{ 0x7f88ed0c, "send_cmd_frame" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x349cba85, "strchr" },
	{ 0x4b32adf, "xproto_unregister" },
	{ 0x9e812e0d, "xpd_driver_register" },
	{ 0xeb66e2b8, "dahdi_rbsbits" },
	{ 0xf9a482f9, "msleep" },
	{ 0xd5f6af81, "device_remove_file" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "xpp,dahdi");


MODULE_INFO(srcversion, "0EEF360573A6DEEEE1F27EB");
MODULE_INFO(rhelversion, "9.8");
