#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x7d7d6fbb, "xframe_next_packet" },
	{ 0xa68e3b05, "xpd_driver_unregister" },
	{ 0x2e79ac2a, "xpd_alloc" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0xe3dfaaf9, "xproto_register" },
	{ 0xe3f0a45a, "xproto_card_entry" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xec5e384c, "notify_bad_xpd" },
	{ 0x4d9adb4a, "get_xframe" },
	{ 0xb67272d2, "xpd_byaddr" },
	{ 0x7f88ed0c, "send_cmd_frame" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x4b32adf, "xproto_unregister" },
	{ 0x9e812e0d, "xpd_driver_register" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "xpp");


MODULE_INFO(srcversion, "1E931F16E0AC37F7F4D5C04");
MODULE_INFO(rhelversion, "9.8");
