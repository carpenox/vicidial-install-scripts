#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x692cf7c3, "seq_printf" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xba83c961, "usb_free_coherent" },
	{ 0xb4b68521, "kmem_cache_free" },
	{ 0xbe1637a1, "kmem_cache_alloc" },
	{ 0xf9d41204, "usb_init_urb" },
	{ 0x72e221ed, "usb_alloc_coherent" },
	{ 0xe1c6c66f, "xframe_init" },
	{ 0xb43f9365, "ktime_get" },
	{ 0xca54a0d, "usb_submit_urb" },
	{ 0x1455bd3, "put_xframe" },
	{ 0x40d5fa67, "dump_xframe" },
	{ 0xcf576d85, "kmem_cache_create" },
	{ 0x4ac0b77c, "usb_register_driver" },
	{ 0x20741215, "kmem_cache_destroy" },
	{ 0x4d9adb4a, "get_xframe" },
	{ 0xacf9e785, "xbus_receive_xframe" },
	{ 0xeaa5bff0, "usb_reset_device" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x2c21b497, "usb_register_dev" },
	{ 0xfeda301f, "xbus_new" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x7551248c, "proc_create_data" },
	{ 0x63b7fc40, "xbus_connect" },
	{ 0x3d672176, "usb_deregister" },
	{ 0xcdafd0b5, "seq_read" },
	{ 0x34928c1, "seq_lseek" },
	{ 0xa01936b1, "single_release" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x3de92247, "param_ops_int" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x122c3a7e, "_printk" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xcd9e968e, "usb_altnum_to_altsetting" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x4b9b2352, "xbus_num" },
	{ 0x9830f204, "remove_proc_entry" },
	{ 0x1b665c02, "xbus_disconnect" },
	{ 0x6626afca, "down" },
	{ 0x2005f832, "usb_deregister_dev" },
	{ 0xcf2a6966, "up" },
	{ 0x37a0cba, "kfree" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x4d56306b, "single_open" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "xpp");

MODULE_ALIAS("usb:vE4E4p1132d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1142d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1152d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:vE4E4p1162d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "6E1A57B6B21E84E97FE3696");
MODULE_INFO(rhelversion, "9.8");
