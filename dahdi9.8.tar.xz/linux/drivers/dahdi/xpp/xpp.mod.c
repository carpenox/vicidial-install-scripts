#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(xbus_statename, "", "");
KSYMTAB_FUNC(xbus_num, "", "");
KSYMTAB_FUNC(xframe_init, "", "");
KSYMTAB_FUNC(xframe_next_packet, "", "");
KSYMTAB_FUNC(dump_xframe, "", "");
KSYMTAB_FUNC(send_pcm_frame, "", "");
KSYMTAB_FUNC(xbus_command_queue_tick, "", "");
KSYMTAB_FUNC(send_cmd_frame, "", "");
KSYMTAB_FUNC(xbus_receive_xframe, "", "");
KSYMTAB_FUNC(xpd_of, "", "");
KSYMTAB_FUNC(xpd_byaddr, "", "");
KSYMTAB_FUNC(xbus_setstate, "", "");
KSYMTAB_FUNC(xbus_activate, "", "");
KSYMTAB_FUNC(xbus_connect, "", "");
KSYMTAB_FUNC(xbus_deactivate, "", "");
KSYMTAB_FUNC(xbus_disconnect, "", "");
KSYMTAB_FUNC(xbus_free, "", "");
KSYMTAB_FUNC(xbus_new, "", "");
KSYMTAB_FUNC(xbus_reset_counters, "", "");
KSYMTAB_FUNC(transportops_get, "", "");
KSYMTAB_FUNC(transportops_put, "", "");
KSYMTAB_FUNC(xpd_driver_register, "", "");
KSYMTAB_FUNC(xpd_driver_unregister, "", "");
KSYMTAB_FUNC(echocancel_xpd, "", "");
KSYMTAB_DATA(pcmtx, "", "");
KSYMTAB_DATA(pcmtx_chan, "", "");
KSYMTAB_FUNC(sync_mode_name, "", "");
KSYMTAB_FUNC(got_new_syncer, "", "");
KSYMTAB_FUNC(xbus_request_sync, "", "");
KSYMTAB_FUNC(dahdi_sync_tick, "", "");
KSYMTAB_FUNC(elect_syncer, "", "");
KSYMTAB_FUNC(update_wanted_pcm_mask, "", "");
KSYMTAB_FUNC(generic_card_pcm_recompute, "", "");
KSYMTAB_FUNC(generic_card_pcm_fromspan, "", "");
KSYMTAB_FUNC(generic_card_pcm_tospan, "", "");
KSYMTAB_FUNC(generic_echocancel_timeslot, "", "");
KSYMTAB_FUNC(generic_echocancel_setmask, "", "");
KSYMTAB_FUNC(generic_timing_priority, "", "");
KSYMTAB_FUNC(xframe_queue_init, "", "");
KSYMTAB_FUNC(xframe_queue_clearstats, "", "");
KSYMTAB_FUNC(xframe_enqueue, "", "");
KSYMTAB_FUNC(xframe_dequeue, "", "");
KSYMTAB_FUNC(xframe_queue_disable, "", "");
KSYMTAB_FUNC(xframe_queue_clear, "", "");
KSYMTAB_FUNC(xframe_queue_count, "", "");
KSYMTAB_FUNC(get_xframe, "", "");
KSYMTAB_FUNC(put_xframe, "", "");
KSYMTAB_DATA(debug, "", "");
KSYMTAB_FUNC(get_xpd, "", "");
KSYMTAB_FUNC(put_xpd, "", "");
KSYMTAB_FUNC(xpd_free, "", "");
KSYMTAB_FUNC(create_xpd, "", "");
KSYMTAB_FUNC(phonedev_alloc_channels, "", "");
KSYMTAB_FUNC(xpd_alloc, "", "");
KSYMTAB_FUNC(update_xpd_status, "", "");
KSYMTAB_FUNC(oht_pcm, "", "");
KSYMTAB_FUNC(mark_offhook, "", "");
KSYMTAB_FUNC(notify_rxsig, "", "");
KSYMTAB_FUNC(hookstate_changed, "", "");
KSYMTAB_FUNC(xpp_open, "", "");
KSYMTAB_FUNC(xpp_close, "", "");
KSYMTAB_FUNC(report_bad_ioctl, "", "");
KSYMTAB_FUNC(xpp_ioctl, "", "");
KSYMTAB_FUNC(xpp_hooksig, "", "");
KSYMTAB_FUNC(xpp_maint, "", "");
KSYMTAB_FUNC(xpp_echocan_name, "", "");
KSYMTAB_FUNC(xpp_echocan_create, "", "");
KSYMTAB_FUNC(xpp_span_assigned, "", "");
KSYMTAB_FUNC(xpd_set_spanname, "", "");
KSYMTAB_FUNC(valid_xpd_addr, "", "");
KSYMTAB_FUNC(xproto_card_entry, "", "");
KSYMTAB_FUNC(xproto_global_entry, "", "");
KSYMTAB_FUNC(notify_bad_xpd, "", "");
KSYMTAB_FUNC(xframe_receive, "", "");
KSYMTAB_FUNC(dump_packet, "", "");
KSYMTAB_FUNC(dump_reg_cmd, "", "");
KSYMTAB_FUNC(xproto_name, "", "");
KSYMTAB_FUNC(xproto_register, "", "");
KSYMTAB_FUNC(xproto_unregister, "", "");
KSYMTAB_FUNC(xpp_register_request, "", "");
KSYMTAB_FUNC(xpp_ram_request, "", "");
KSYMTAB_FUNC(run_initialize_registers, "", "");
KSYMTAB_FUNC(dump_poll, "", "");
KSYMTAB_FUNC(alarm2str, "", "");

SYMBOL_CRC(xbus_statename, 0x6aa023ac, "");
SYMBOL_CRC(xbus_num, 0x4b9b2352, "");
SYMBOL_CRC(xframe_init, 0xe1c6c66f, "");
SYMBOL_CRC(xframe_next_packet, 0x7d7d6fbb, "");
SYMBOL_CRC(dump_xframe, 0x40d5fa67, "");
SYMBOL_CRC(send_pcm_frame, 0xd3419e7f, "");
SYMBOL_CRC(xbus_command_queue_tick, 0x7b387a7d, "");
SYMBOL_CRC(send_cmd_frame, 0x7f88ed0c, "");
SYMBOL_CRC(xbus_receive_xframe, 0xacf9e785, "");
SYMBOL_CRC(xpd_of, 0xbb4de9c1, "");
SYMBOL_CRC(xpd_byaddr, 0xb67272d2, "");
SYMBOL_CRC(xbus_setstate, 0x477fcfd2, "");
SYMBOL_CRC(xbus_activate, 0x4371dc31, "");
SYMBOL_CRC(xbus_connect, 0x63b7fc40, "");
SYMBOL_CRC(xbus_deactivate, 0xb6c5d663, "");
SYMBOL_CRC(xbus_disconnect, 0x1b665c02, "");
SYMBOL_CRC(xbus_free, 0xb00ea48d, "");
SYMBOL_CRC(xbus_new, 0xfeda301f, "");
SYMBOL_CRC(xbus_reset_counters, 0x2bcf208a, "");
SYMBOL_CRC(transportops_get, 0x59d2d4da, "");
SYMBOL_CRC(transportops_put, 0xfe2e05ea, "");
SYMBOL_CRC(xpd_driver_register, 0x9e812e0d, "");
SYMBOL_CRC(xpd_driver_unregister, 0xa68e3b05, "");
SYMBOL_CRC(echocancel_xpd, 0x055377fb, "");
SYMBOL_CRC(pcmtx, 0x2ef28734, "");
SYMBOL_CRC(pcmtx_chan, 0x0c3b63d8, "");
SYMBOL_CRC(sync_mode_name, 0xe6ce6bea, "");
SYMBOL_CRC(got_new_syncer, 0x188f26d0, "");
SYMBOL_CRC(xbus_request_sync, 0x6a97df7e, "");
SYMBOL_CRC(dahdi_sync_tick, 0x20c1a87c, "");
SYMBOL_CRC(elect_syncer, 0xb2cc48ff, "");
SYMBOL_CRC(update_wanted_pcm_mask, 0xe84a4e7e, "");
SYMBOL_CRC(generic_card_pcm_recompute, 0xefdbb440, "");
SYMBOL_CRC(generic_card_pcm_fromspan, 0x442a969b, "");
SYMBOL_CRC(generic_card_pcm_tospan, 0x3759bc54, "");
SYMBOL_CRC(generic_echocancel_timeslot, 0x4cb74149, "");
SYMBOL_CRC(generic_echocancel_setmask, 0x220378b3, "");
SYMBOL_CRC(generic_timing_priority, 0x6ff45dc5, "");
SYMBOL_CRC(xframe_queue_init, 0xe1912fe9, "");
SYMBOL_CRC(xframe_queue_clearstats, 0x2ad9cef6, "");
SYMBOL_CRC(xframe_enqueue, 0xf3dcd36d, "");
SYMBOL_CRC(xframe_dequeue, 0x39ed2e5f, "");
SYMBOL_CRC(xframe_queue_disable, 0xc0d42745, "");
SYMBOL_CRC(xframe_queue_clear, 0xabe57ac8, "");
SYMBOL_CRC(xframe_queue_count, 0x4ce9c215, "");
SYMBOL_CRC(get_xframe, 0x4d9adb4a, "");
SYMBOL_CRC(put_xframe, 0x01455bd3, "");
SYMBOL_CRC(debug, 0xad0e46e6, "");
SYMBOL_CRC(get_xpd, 0xff306747, "");
SYMBOL_CRC(put_xpd, 0x9c670a6c, "");
SYMBOL_CRC(xpd_free, 0x42ab5778, "");
SYMBOL_CRC(create_xpd, 0xb10981f5, "");
SYMBOL_CRC(phonedev_alloc_channels, 0x4130bfe5, "");
SYMBOL_CRC(xpd_alloc, 0x2e79ac2a, "");
SYMBOL_CRC(update_xpd_status, 0x66902ede, "");
SYMBOL_CRC(oht_pcm, 0xd496300b, "");
SYMBOL_CRC(mark_offhook, 0x5af82912, "");
SYMBOL_CRC(notify_rxsig, 0x92e38267, "");
SYMBOL_CRC(hookstate_changed, 0x543020e5, "");
SYMBOL_CRC(xpp_open, 0x1663fcfc, "");
SYMBOL_CRC(xpp_close, 0x1ee9ef91, "");
SYMBOL_CRC(report_bad_ioctl, 0xcbd6d4f5, "");
SYMBOL_CRC(xpp_ioctl, 0xbaad7b8d, "");
SYMBOL_CRC(xpp_hooksig, 0xc37c49f2, "");
SYMBOL_CRC(xpp_maint, 0x2f8b1791, "");
SYMBOL_CRC(xpp_echocan_name, 0x9135474d, "");
SYMBOL_CRC(xpp_echocan_create, 0x7979af1c, "");
SYMBOL_CRC(xpp_span_assigned, 0x8f7a7c41, "");
SYMBOL_CRC(xpd_set_spanname, 0x3ba889a4, "");
SYMBOL_CRC(valid_xpd_addr, 0xedef3c9f, "");
SYMBOL_CRC(xproto_card_entry, 0xe3f0a45a, "");
SYMBOL_CRC(xproto_global_entry, 0xe65cf22f, "");
SYMBOL_CRC(notify_bad_xpd, 0xec5e384c, "");
SYMBOL_CRC(xframe_receive, 0xbb5ea533, "");
SYMBOL_CRC(dump_packet, 0x97438c62, "");
SYMBOL_CRC(dump_reg_cmd, 0xe0d90fd0, "");
SYMBOL_CRC(xproto_name, 0x10ddaf27, "");
SYMBOL_CRC(xproto_register, 0xe3dfaaf9, "");
SYMBOL_CRC(xproto_unregister, 0x04b32adf, "");
SYMBOL_CRC(xpp_register_request, 0x566f684f, "");
SYMBOL_CRC(xpp_ram_request, 0x0ef2ce92, "");
SYMBOL_CRC(run_initialize_registers, 0x8163a0be, "");
SYMBOL_CRC(dump_poll, 0x821b2778, "");
SYMBOL_CRC(alarm2str, 0x64a6fdeb, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x9c6febfc, "add_uevent_var" },
	{ 0xdf68b21a, "try_module_get" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x3dfcc644, "dev_set_name" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x1e6674a7, "device_unregister" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x9e22a8e, "dahdi_alarm_notify" },
	{ 0xcf2a6966, "up" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x69acdf38, "memcpy" },
	{ 0x37a0cba, "kfree" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0x34928c1, "seq_lseek" },
	{ 0x7551248c, "proc_create_data" },
	{ 0x9f15f501, "timer_delete" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xe2964344, "__wake_up" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xa916b694, "strnlen" },
	{ 0x680a04a6, "module_put" },
	{ 0xc20414fb, "sysfs_create_link" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x93a4f6e7, "device_create_file" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x442b102b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x86412482, "bus_unregister" },
	{ 0xea909b12, "sysfs_remove_link" },
	{ 0xb8acf091, "dahdi_create_device" },
	{ 0x3cf85989, "mod_timer" },
	{ 0xa7eedcc4, "call_usermodehelper" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0x6626afca, "down" },
	{ 0x4a0de96c, "dahdi_qevent_lock" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x7aae1ec9, "dahdi_hooksig" },
	{ 0x5a921311, "strncmp" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x4a19ad77, "driver_unregister" },
	{ 0x53a1e8d9, "_find_next_bit" },
	{ 0x5a5a2271, "__cpu_online_mask" },
	{ 0x9ed12e20, "kmalloc_large" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xbcab6ee6, "sscanf" },
	{ 0x9d281dd8, "dahdi_unregister_device" },
	{ 0x89940875, "mutex_lock_interruptible" },
	{ 0xe9ffc063, "down_trylock" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x11089ac7, "_ctype" },
	{ 0x69819809, "device_register" },
	{ 0x32f55b2c, "proc_mkdir" },
	{ 0xfb578fc5, "memset" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xfb384d37, "kasprintf" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xcdafd0b5, "seq_read" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x1ac5d3cb, "strcspn" },
	{ 0x85df9b6c, "strsep" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x823ae8b8, "param_ops_bool" },
	{ 0x679d4479, "__dahdi_ec_chunk" },
	{ 0x65d8edc0, "dahdi_get_auto_assign_spans" },
	{ 0x9830f204, "remove_proc_entry" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x692cf7c3, "seq_printf" },
	{ 0x20000329, "simple_strtoul" },
	{ 0xd7b1abdd, "kobject_uevent" },
	{ 0xa01936b1, "single_release" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x754d539c, "strlen" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x4d56306b, "single_open" },
	{ 0x349cba85, "strchr" },
	{ 0x98826cf, "dahdi_free_device" },
	{ 0xf90a1e85, "__x86_indirect_thunk_r8" },
	{ 0xd35ce85b, "driver_register" },
	{ 0xf9a482f9, "msleep" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x92d911b7, "_dahdi_transmit" },
	{ 0xd5f6af81, "device_remove_file" },
	{ 0x3c9e0a55, "module_refcount" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x1c432eb5, "bus_register" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "913AC57FCAF99189AEF22F9");
MODULE_INFO(rhelversion, "9.8");
