#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x22ec5205, "cpu_latency_qos_remove_request" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xdf68b21a, "try_module_get" },
	{ 0xf6480e98, "param_ops_uint" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x11956249, "pci_enable_device" },
	{ 0x4a453f53, "iowrite32" },
	{ 0x6a8a7260, "pci_iomap" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x8a84ad48, "__pci_register_driver" },
	{ 0xedc03953, "iounmap" },
	{ 0x854f6e90, "pci_request_regions" },
	{ 0x28afbb08, "cpu_latency_qos_add_request" },
	{ 0x37a0cba, "kfree" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xf342750a, "pci_unregister_driver" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x122c3a7e, "_printk" },
	{ 0x848d372e, "iowrite8" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0xa5479a2, "__tracepoint_sched_set_state_tp" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x680a04a6, "module_put" },
	{ 0x442b102b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xb8acf091, "dahdi_create_device" },
	{ 0x4a0de96c, "dahdi_qevent_lock" },
	{ 0x7aae1ec9, "dahdi_hooksig" },
	{ 0xfbc199da, "dma_alloc_attrs" },
	{ 0xde80cd09, "ioremap" },
	{ 0x9ed12e20, "kmalloc_large" },
	{ 0x9d281dd8, "dahdi_unregister_device" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd9becdfb, "pci_iounmap" },
	{ 0xb19b445, "ioread8" },
	{ 0x6fcb87a1, "touch_softlockup_watchdog" },
	{ 0xfb578fc5, "memset" },
	{ 0x1938d602, "pci_set_master" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xfb384d37, "kasprintf" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x1a4c24cc, "dma_free_attrs" },
	{ 0x679d4479, "__dahdi_ec_chunk" },
	{ 0x23f56e03, "pci_release_regions" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0x77317a9b, "dahdi_alarm_channel" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x98826cf, "dahdi_free_device" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x53bbefe1, "__trace_set_current_state" },
	{ 0x92d911b7, "_dahdi_transmit" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi");

MODULE_ALIAS("pci:v0000E159d00000001sv00009100sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00009519sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv000095D9sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00009500sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00009532sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00008519sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00009559sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000E159d00000001sv00009599sd*bc*sc*i*");

MODULE_INFO(srcversion, "D627B8469BDE756CAA135D3");
MODULE_INFO(rhelversion, "9.8");
