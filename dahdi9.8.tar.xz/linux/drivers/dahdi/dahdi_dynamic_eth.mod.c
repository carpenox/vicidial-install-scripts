#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x122c3a7e, "_printk" },
	{ 0x37a0cba, "kfree" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x68371abe, "dahdi_dynamic_unregister_driver" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0x90c7486b, "dev_remove_pack" },
	{ 0xacfbf941, "skb_queue_purge_reason" },
	{ 0x7116511, "__netdev_alloc_skb" },
	{ 0x46b3f072, "skb_put" },
	{ 0x69acdf38, "memcpy" },
	{ 0xcbbc492, "skb_push" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x6572cf93, "skb_queue_tail" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x30762348, "skb_pull" },
	{ 0xa72a0a41, "dahdi_dynamic_receive" },
	{ 0xa2646207, "sk_skb_reason_drop" },
	{ 0x7dfc5eec, "__pskb_pull_tail" },
	{ 0x754d539c, "strlen" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0xa916b694, "strnlen" },
	{ 0x476b165a, "sized_strscpy" },
	{ 0x349cba85, "strchr" },
	{ 0xbf830568, "init_net" },
	{ 0x65201ddf, "dev_get_by_name" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xf6146f6f, "dev_add_pack" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0xebb429d3, "dahdi_dynamic_register_driver" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x15ed2b9e, "__dev_queue_xmit" },
	{ 0x80dd25d9, "skb_dequeue" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi_dynamic");


MODULE_INFO(srcversion, "24D22E1D41021D76F6936B8");
MODULE_INFO(rhelversion, "9.8");
