/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wcaxx-base.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wcxb_spi.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wcxb.o
/usr/src/dahdi-linux-complete-3.4.0+3.4.0/linux/drivers/dahdi/wcxb_flash.o
