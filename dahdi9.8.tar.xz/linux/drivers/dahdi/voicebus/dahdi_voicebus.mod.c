#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(voicebus_set_minlatency, "", "");
KSYMTAB_FUNC(voicebus_current_latency, "", "");
KSYMTAB_FUNC(voicebus_transmit, "", "");
KSYMTAB_FUNC(voicebus_start, "", "");
KSYMTAB_FUNC(voicebus_stop, "", "");
KSYMTAB_FUNC(voicebus_quiesce, "", "");
KSYMTAB_FUNC(voicebus_release, "", "");
KSYMTAB_FUNC(__voicebus_init, "", "");
KSYMTAB_FUNC(vpmadtreg_register, "", "");
KSYMTAB_FUNC(vpmadtreg_unregister, "", "");
KSYMTAB_FUNC(vpmadt032_echocan_create, "", "");
KSYMTAB_FUNC(vpmadt032_echocan_free, "", "");
KSYMTAB_FUNC(vpmadt032_alloc, "", "");
KSYMTAB_FUNC(vpmadt032_reset, "", "");
KSYMTAB_FUNC(vpmadt032_test, "", "");
KSYMTAB_FUNC(vpmadt032_init, "", "");
KSYMTAB_FUNC(vpmadt032_get_default_parameters, "", "");
KSYMTAB_FUNC(vpmadt032_free, "", "");
KSYMTAB_FUNC(gpakConfigurePorts, "", "");
KSYMTAB_FUNC(gpakConfigureChannel, "", "");
KSYMTAB_FUNC(gpakAlgControl, "", "");
KSYMTAB_FUNC(gpakPingDsp, "", "");
KSYMTAB_FUNC(vpmoct_alloc, "", "");
KSYMTAB_FUNC(vpmoct_free, "", "");
KSYMTAB_FUNC(vpmoct_init, "", "");
KSYMTAB_FUNC(vpmoct_echocan_create, "", "");
KSYMTAB_FUNC(vpmoct_echocan_free, "", "");
KSYMTAB_FUNC(vpmoct_preecho_enable, "", "");
KSYMTAB_FUNC(vpmoct_preecho_disable, "", "");

SYMBOL_CRC(voicebus_set_minlatency, 0x46cf137f, "");
SYMBOL_CRC(voicebus_current_latency, 0x8761b753, "");
SYMBOL_CRC(voicebus_transmit, 0xdd90e922, "");
SYMBOL_CRC(voicebus_start, 0x0a5fe85b, "");
SYMBOL_CRC(voicebus_stop, 0x583a3752, "");
SYMBOL_CRC(voicebus_quiesce, 0x234ca2a8, "");
SYMBOL_CRC(voicebus_release, 0x5611ee87, "");
SYMBOL_CRC(__voicebus_init, 0x13e887a1, "");
SYMBOL_CRC(vpmadtreg_register, 0x353d85b7, "");
SYMBOL_CRC(vpmadtreg_unregister, 0x80d5d559, "");
SYMBOL_CRC(vpmadt032_echocan_create, 0x232ce1da, "");
SYMBOL_CRC(vpmadt032_echocan_free, 0xa19b0260, "");
SYMBOL_CRC(vpmadt032_alloc, 0xe9279ba2, "");
SYMBOL_CRC(vpmadt032_reset, 0xd3c3b0b5, "");
SYMBOL_CRC(vpmadt032_test, 0x00846901, "");
SYMBOL_CRC(vpmadt032_init, 0x4d6dbc5f, "");
SYMBOL_CRC(vpmadt032_get_default_parameters, 0x102cf10b, "");
SYMBOL_CRC(vpmadt032_free, 0x0b21bd9a, "");
SYMBOL_CRC(gpakConfigurePorts, 0x635a1d83, "");
SYMBOL_CRC(gpakConfigureChannel, 0xe8a9b8fa, "");
SYMBOL_CRC(gpakAlgControl, 0x8019389a, "");
SYMBOL_CRC(gpakPingDsp, 0xe5eb1132, "");
SYMBOL_CRC(vpmoct_alloc, 0xc5bde2d3, "");
SYMBOL_CRC(vpmoct_free, 0xd4241c31, "");
SYMBOL_CRC(vpmoct_init, 0x9f784110, "");
SYMBOL_CRC(vpmoct_echocan_create, 0x7d6a9766, "");
SYMBOL_CRC(vpmoct_echocan_free, 0xfd0dcc85, "");
SYMBOL_CRC(vpmoct_preecho_enable, 0x919a0bce, "");
SYMBOL_CRC(vpmoct_preecho_disable, 0xc8558d26, "");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc1514a3b, "free_irq" },
	{ 0xdf68b21a, "try_module_get" },
	{ 0xc6d09aa9, "release_firmware" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0xf249220c, "dma_pool_create" },
	{ 0x4a3ad70e, "wait_for_completion_timeout" },
	{ 0x11956249, "pci_enable_device" },
	{ 0x6a8a7260, "pci_iomap" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0x8ad215cc, "request_firmware" },
	{ 0xcf2a6966, "up" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x37a0cba, "kfree" },
	{ 0xfcec0987, "enable_irq" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0xc96c4376, "pci_clear_mwi" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x3c5d2d76, "__dynamic_dev_dbg" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x1035c7c2, "__release_region" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x678b96ec, "dma_pool_alloc" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x749cbadd, "_dev_info" },
	{ 0x680a04a6, "module_put" },
	{ 0x4ed815c7, "pci_set_mwi" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x2f60ef0a, "_dev_err" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x2f7754a8, "dma_pool_free" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0x6626afca, "down" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xfbc199da, "dma_alloc_attrs" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xd9becdfb, "pci_iounmap" },
	{ 0x11089ac7, "_ctype" },
	{ 0xfb578fc5, "memset" },
	{ 0xa175a655, "_dev_warn" },
	{ 0x1938d602, "pci_set_master" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x41e338a2, "_dev_notice" },
	{ 0xb5aa7165, "dma_pool_destroy" },
	{ 0x1a4c24cc, "dma_free_attrs" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x2a53b7e8, "pci_disable_device" },
	{ 0xd391db23, "dma_set_mask" },
	{ 0x362f9a8, "__x86_indirect_thunk_r12" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0x4e7e73a4, "pci_read_config_byte" },
	{ 0x77358855, "iomem_resource" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xf9a482f9, "msleep" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x85bd1608, "__request_region" },
	{ 0xa24f23d8, "__request_module" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x3ce4ca6f, "disable_irq" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi");


MODULE_INFO(srcversion, "D98EA2F82C96A1C52F2CB5D");
MODULE_INFO(rhelversion, "9.8");
