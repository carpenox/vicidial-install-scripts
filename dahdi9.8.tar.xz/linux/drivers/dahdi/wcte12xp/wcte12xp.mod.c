#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_MITIGATION_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc8558d26, "vpmoct_preecho_disable" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0x4a3ad70e, "wait_for_completion_timeout" },
	{ 0x234ca2a8, "voicebus_quiesce" },
	{ 0xfd0dcc85, "vpmoct_echocan_free" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xa6257a2f, "complete" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0x9e22a8e, "dahdi_alarm_notify" },
	{ 0x232ce1da, "vpmadt032_echocan_create" },
	{ 0x8a84ad48, "__pci_register_driver" },
	{ 0x7d6a9766, "vpmoct_echocan_create" },
	{ 0x6128b5fc, "__printk_ratelimit" },
	{ 0x37a0cba, "kfree" },
	{ 0xd294630d, "pcpu_hot" },
	{ 0xb3087f55, "timer_delete_sync" },
	{ 0xcf576d85, "kmem_cache_create" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xcc5005fe, "msleep_interruptible" },
	{ 0xf342750a, "pci_unregister_driver" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xf02aa937, "wait_for_completion_interruptible_timeout" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xe5eb1132, "gpakPingDsp" },
	{ 0xbe1637a1, "kmem_cache_alloc" },
	{ 0x749cbadd, "_dev_info" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0xc5bde2d3, "vpmoct_alloc" },
	{ 0x442b102b, "_dahdi_receive" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x2f60ef0a, "_dev_err" },
	{ 0xa5fe85b, "voicebus_start" },
	{ 0xb8acf091, "dahdi_create_device" },
	{ 0xd3c3b0b5, "vpmadt032_reset" },
	{ 0x3cf85989, "mod_timer" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0xb4b68521, "kmem_cache_free" },
	{ 0x102cf10b, "vpmadt032_get_default_parameters" },
	{ 0xd4241c31, "vpmoct_free" },
	{ 0xaafdc258, "strcasecmp" },
	{ 0x5611ee87, "voicebus_release" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x642e7b9, "dahdi_init_span" },
	{ 0x9d281dd8, "dahdi_unregister_device" },
	{ 0x846901, "vpmadt032_test" },
	{ 0x4c29be43, "dahdi_spantype2str" },
	{ 0xf8c888d4, "dahdi_register_device" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4d6dbc5f, "vpmadt032_init" },
	{ 0xa175a655, "_dev_warn" },
	{ 0x8019389a, "gpakAlgControl" },
	{ 0x19f465bb, "param_ops_charp" },
	{ 0x9166fc03, "__flush_workqueue" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x46cf137f, "voicebus_set_minlatency" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x41e338a2, "_dev_notice" },
	{ 0xa19b0260, "vpmadt032_echocan_free" },
	{ 0x78534f62, "init_timer_key" },
	{ 0x679d4479, "__dahdi_ec_chunk" },
	{ 0x13e887a1, "__voicebus_init" },
	{ 0x9f784110, "vpmoct_init" },
	{ 0xe8a9b8fa, "gpakConfigureChannel" },
	{ 0x544be8df, "kmalloc_trace" },
	{ 0xe9279ba2, "vpmadt032_alloc" },
	{ 0x3de92247, "param_ops_int" },
	{ 0x98826cf, "dahdi_free_device" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0xeb66e2b8, "dahdi_rbsbits" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0xb21bd9a, "vpmadt032_free" },
	{ 0x4344f508, "kmalloc_caches" },
	{ 0x92d911b7, "_dahdi_transmit" },
	{ 0x20741215, "kmem_cache_destroy" },
	{ 0x635a1d83, "gpakConfigurePorts" },
	{ 0x919a0bce, "vpmoct_preecho_enable" },
	{ 0x3075a628, "module_layout" },
};

MODULE_INFO(depends, "dahdi_voicebus,dahdi");

MODULE_ALIAS("pci:v0000D161d00000120sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008000sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000D161d00008001sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "4AC86103E85A49D2E21801A");
MODULE_INFO(rhelversion, "9.8");
